﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Denicolas_Raul_HW0.Models;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Denicolas_Raul_HW0.Controllers
{
    public class HomeController : Controller
    { 
        public IActionResult Index()
        {
        return View();
        }

        [HttpGet]
        public IActionResult RsvpForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult RsvpForm(GuestResponse guestResponse)
        {
            if (ModelState.IsValid == false) //response is not valid
            {
                return View();
            }
            //Add the reponse to the repository
            Repository.AddResponse(guestResponse);

            //Return the Thanks view with the response data
            return View("Thanks", guestResponse);
        }

        public IActionResult ListResponses()
        {
            IEnumerable<GuestResponse> attende_List = Repository.Responses
                                                      .Where(r => r.WillAttend == true);
            return View(attende_List);
        }
    }
}

