﻿//Name: Raul Denicolas
//Date: September 22, 2022
//Description: HW2 – Bookstore Checkout

using Microsoft.AspNetCore.Mvc;

//you need to give the controllers namespace access to your models
using Denicolas_Raul_HW2.Models;

namespace Denicolas_Raul_HW2.Controllers
{
    public class HomeController : Controller
    {
    

        // GET: Index View
        public IActionResult Index()
        {
            return View();
        }

        //GET:Check out Direct view
        public IActionResult CheckoutDirect()
        {
            return View();
        }

        //GET: Direct Totals With parameters
        public IActionResult DirectTotals(DirectOrder directOrder)
        {
            TryValidateModel(directOrder);

            //if model state is not correct, send user back to the view
            if (ModelState.IsValid == false) //something is wrong
            {
                //go back to the create view
                ViewBag.Error = "Please make sure you have entered valid data!";
                return View("CheckoutDirect", directOrder);
            }

            directOrder.CustomerType = CustomerType.Direct;

            try
            {
                directOrder.CalculateTotals();
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message + " " + ex.InnerException.Message;
                return View("CheckoutDirect", directOrder);
            }
            return View(directOrder);
        }


        //GET:Whole sale view
        public IActionResult CheckoutWholesale()
        {
            return View();
        }


        //GET:Wholesale totals view with parameters
        public IActionResult WholesaleTotals(WholesaleOrder wholesaleOrder)
        {
            TryValidateModel(wholesaleOrder);

            //if model state is not correct, send user back to the view
            if (ModelState.IsValid == false) //something is wrong
            {
                //go back to the create view
                ViewBag.Error = "Please make sure you have entered valid data!";
                return View("CheckoutWholesale", wholesaleOrder);
            }

            wholesaleOrder.CustomerType = CustomerType.Wholesale;


            wholesaleOrder.CalculateTotals();


            return View(wholesaleOrder);
        }

    }
}

