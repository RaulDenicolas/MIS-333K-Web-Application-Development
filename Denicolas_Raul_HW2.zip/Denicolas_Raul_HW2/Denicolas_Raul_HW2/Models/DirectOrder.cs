﻿using System.ComponentModel.DataAnnotations;

namespace Denicolas_Raul_HW2.Models
{
    public class DirectOrder : Order
    {
        //Create field for sales tax rate
        public const Decimal SALES_TAX_RATE = 8.25m;
        internal CustomerType CustomerType;

        //display customer name
        [Display(Name = "Customer Name:")]
        public String? CustomerName { get; set; }

        // create property for sales tax
        [Display(Name = "Sales Tax:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal SalesTax { get; private set; }

        public void CalculateTotals()
        {
            try
            {
                base.CalculateSubtotals();
               
            }
                catch (Exception ex)
            {
                throw new Exception("There was an error.", ex);
            }
            SalesTax = base.Subtotal * SALES_TAX_RATE;
            Total = base.Subtotal + SalesTax;

        }
    }
}