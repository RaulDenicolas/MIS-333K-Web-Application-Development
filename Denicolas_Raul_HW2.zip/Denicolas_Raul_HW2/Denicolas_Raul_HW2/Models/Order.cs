﻿//add using directive for the data annotations
using System.ComponentModel.DataAnnotations;

namespace Denicolas_Raul_HW2.Models
{
    public enum CustomerType { Direct, Wholesale }

    public class Order
    {
        //Set constants for prices (fields)
        public const Decimal HARDBACK_PRICE = 17.95m;
        public const Decimal PAPERBACK_PRICE = 9.50m;

        //Create a number for amount of Hardbacks
        [Display(Name = "Number of Hardbacks:")]
        [DisplayFormat(DataFormatString = "{0:n0}")]
        [Required(ErrorMessage = "Number of hardbacks is required!")]
        [Range(0, 10000, ErrorMessage = "The number of hardbacks must be at least zero!")]

        public Int32 NumberOfHardbacks { get; set; }

        //Create a number for amount of Paperbacks
        [Display(Name = "Number of Paperbacks:")]
        [DisplayFormat(DataFormatString = "{0:n0}")]
        [Required(ErrorMessage = "Number of paperbacks is required!")]
        [Range(0, 10000, ErrorMessage = "The number of paperbacks must be at least zero!")]
        public Int32 NumberOfPaperbacks { get; set; }

        //Create a method to calculate Hardback subtotal
        [Display(Name = "Hardback Subtotal:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal HardbackSubtotal { get; private set; }

        //Create a method to calculate Paperback subtotal
        [Display(Name = "Paperback Subtotal:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal PaperbackSubtotal { get; private set; }

        //Create method for Subtotal
        [Display(Name = "Subtotal:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Subtotal { get; private set; }

        [Display(Name = "Total:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        public Decimal Total { get; set; }

        //Create method for Total Items
        [Display(Name = "Total number of books:")]
        public Decimal TotalItems { get; private set; }

        public void CalculateSubtotals()
        {

            HardbackSubtotal = NumberOfHardbacks * HARDBACK_PRICE;
            PaperbackSubtotal = NumberOfPaperbacks * PAPERBACK_PRICE;
            TotalItems = NumberOfHardbacks + NumberOfPaperbacks;
            Subtotal = HardbackSubtotal + PaperbackSubtotal;

            if (TotalItems != 0)
            throw new Exception("There was an error.");
        }
    }
}