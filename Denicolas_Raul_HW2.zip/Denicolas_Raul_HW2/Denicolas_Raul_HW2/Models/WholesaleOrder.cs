﻿using System.ComponentModel.DataAnnotations;

namespace Denicolas_Raul_HW2.Models
{
    public class WholesaleOrder : Order
    {
        internal CustomerType CustomerType;

        [Display(Name = "Customer Code:")]
        [Required(ErrorMessage = "Customer code is required!")]
        [StringLength(6, MinimumLength =4, ErrorMessage = "Customer code must be 4 - 6 characters")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Customer code may only contain letters")]
        public String? CustomerCode { get; set; }

        [Display(Name = "Delivery Fee:")]
        [DisplayFormat(DataFormatString = "{0:c}")]
        [Required(ErrorMessage = "The Delivery Fee: field is required.")]
        [Range(0, 250, ErrorMessage = "Monthly salary must be between $0 and $250")]
        public Decimal DeliveryFee { get; set; }

        [Display(Name = "Is this customer a preferred customer?")]
        public Boolean PreferredCustomer { get; set; }

        public void CalculateTotals()
        {
        try
        {
            base.CalculateSubtotals();
        }
        catch (Exception ex)
        {
        throw new Exception("There was an error.", ex);
        }
        if (PreferredCustomer == true || Subtotal >= 1200)
        DeliveryFee = 0;
        Total = base.Subtotal + DeliveryFee;
        }
    }
}